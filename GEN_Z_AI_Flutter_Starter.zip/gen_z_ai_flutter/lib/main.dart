import 'package:flutter/material.dart';

void main() => runApp(const GenZAIApp());

const Color ink = Color(0xFF101426);
const Color panel = Color(0xFF1A2038);
const Color violet = Color(0xFF7967FF);
const Color cyan = Color(0xFF53D6D0);

class GenZAIApp extends StatelessWidget {
  const GenZAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GEN Z AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: violet,
          brightness: Brightness.dark,
          surface: ink,
        ),
        fontFamily: 'Roboto',
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;

  final pages = const [
    HomePage(),
    ChatPage(),
    HistoryPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[selected]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF171C30),
        indicatorColor: violet.withOpacity(.22),
        selectedIndex: selected,
        onDestinationSelected: (value) => setState(() => selected = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = [
      ToolInfo('AI Chat', 'Ask anything', Icons.chat_rounded, violet),
      ToolInfo('AI Image', 'Create art from text', Icons.image_rounded, const Color(0xFFFF9D66)),
      ToolInfo('Photo Editor', 'Enhance your photos', Icons.auto_fix_high_rounded, cyan),
      ToolInfo('AI Video', 'Turn ideas into videos', Icons.movie_creation_rounded, const Color(0xFFFF6D9E)),
      ToolInfo('AI Voice', 'Talk to your assistant', Icons.mic_rounded, const Color(0xFF7DB4FF)),
      ToolInfo('Translator', 'Translate languages', Icons.translate_rounded, const Color(0xFFFFD166)),
      ToolInfo('AI Writer', 'Captions, posts and more', Icons.edit_note_rounded, const Color(0xFFB69CFF)),
      ToolInfo('Summarizer', 'Make long text shorter', Icons.summarize_rounded, const Color(0xFF78D7A5)),
    ];

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
      children: [
        Row(
          children: [
            Container(
              height: 46, width: 46,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(colors: [violet, cyan]),
              ),
              child: const Icon(Icons.auto_awesome, color: Colors.white, size: 27),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('GEN Z AI', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: 1)),
                Text('YOUR ALL-IN-ONE AI ASSISTANT', style: TextStyle(fontSize: 9, color: Colors.white60, letterSpacing: 1.1)),
              ],
            ),
            const Spacer(),
            IconButton(
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Notifications will be available in a future update.')),
              ),
              icon: const Icon(Icons.notifications_none_rounded),
            ),
          ],
        ),
        const SizedBox(height: 26),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(25),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF5144B8), Color(0xFF242B55), Color(0xFF1A5260)],
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(20)),
                child: const Text('✨  YOUR AI SPACE', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 15),
              const Text('Imagine it.\nCreate it with AI.', style: TextStyle(fontSize: 27, height: 1.15, fontWeight: FontWeight.w800)),
              const SizedBox(height: 9),
              const Text('আপনার আইডিয়া লিখুন, শুরু হোক নতুন কিছু।', style: TextStyle(color: Colors.white70, fontSize: 13)),
              const SizedBox(height: 18),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: ink),
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ChatPage())),
                icon: const Icon(Icons.chat_bubble_outline, size: 18),
                label: const Text('Start chatting'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 27),
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Explore AI tools', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('8 tools', style: TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        ),
        const SizedBox(height: 14),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: tools.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.42,
          ),
          itemBuilder: (context, index) => ToolCard(info: tools[index]),
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17)),
          child: const Row(
            children: [
              Icon(Icons.info_outline, color: cyan),
              SizedBox(width: 11),
              Expanded(child: Text('Starter version: AI tools are UI previews. Connect secure AI services to make them live.', style: TextStyle(fontSize: 11, color: Colors.white70, height: 1.4))),
            ],
          ),
        ),
      ],
    );
  }
}

class ToolInfo {
  final String title, subtitle;
  final IconData icon;
  final Color color;
  ToolInfo(this.title, this.subtitle, this.icon, this.color);
}

class ToolCard extends StatelessWidget {
  final ToolInfo info;
  const ToolCard({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        if (info.title == 'AI Chat') {
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ChatPage()));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${info.title} will be activated after its AI service is connected.')),
          );
        }
      },
      child: Ink(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.05))),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 38, width: 38,
              decoration: BoxDecoration(color: info.color.withOpacity(.15), borderRadius: BorderRadius.circular(12)),
              child: Icon(info.icon, color: info.color),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(info.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 3),
                Text(info.subtitle, style: const TextStyle(color: Colors.white54, fontSize: 10), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final messages = <String>[
    'আসসালামু আলাইকুম! আমি GEN Z AI। কীভাবে আপনাকে সাহায্য করতে পারি?',
  ];

  void send() {
    final value = controller.text.trim();
    if (value.isEmpty) return;
    setState(() {
      messages.add(value);
      messages.add('আপনার প্রশ্নটি পেয়েছি। এটি Starter Demo—বাস্তব AI উত্তর পেতে পরবর্তী ধাপে নিরাপদ AI API যুক্ত করতে হবে।');
    });
    controller.clear();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('GEN Z AI Chat', style: TextStyle(fontWeight: FontWeight.bold)), backgroundColor: ink),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final isUser = index > 0 && index.isOdd;
                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 310),
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isUser ? const Color(0xFF5144B8) : panel,
                      borderRadius: BorderRadius.circular(17),
                    ),
                    child: Text(messages[index], style: const TextStyle(fontSize: 14, height: 1.45)),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      onSubmitted: (_) => send(),
                      decoration: InputDecoration(
                        hintText: 'এখানে লিখুন...',
                        filled: true, fillColor: panel,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    style: IconButton.styleFrom(backgroundColor: violet, minimumSize: const Size(48, 48)),
                    onPressed: send,
                    icon: const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(
      padding: EdgeInsets.all(28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.history, size: 55, color: violet),
          SizedBox(height: 14),
          Text('Your history will appear here', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          SizedBox(height: 7),
          Text('আপনার AI কথোপকথন ও তৈরি করা কনটেন্ট সংরক্ষণের সুবিধা পরবর্তী ধাপে যুক্ত হবে।', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, height: 1.5)),
        ],
      ),
    ),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(22),
    children: [
      const SizedBox(height: 20),
      const CircleAvatar(radius: 38, backgroundColor: violet, child: Icon(Icons.person, size: 42, color: Colors.white)),
      const SizedBox(height: 13),
      const Center(child: Text('GEN Z AI User', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 19))),
      const Center(child: Text('Free starter account', style: TextStyle(color: Colors.white54))),
      const SizedBox(height: 30),
      const SettingsTile(icon: Icons.language, title: 'Language', subtitle: 'বাংলা / English'),
      const SettingsTile(icon: Icons.palette_outlined, title: 'Appearance', subtitle: 'Dark theme'),
      const SettingsTile(icon: Icons.privacy_tip_outlined, title: 'Privacy & security', subtitle: 'Coming soon'),
      const SettingsTile(icon: Icons.info_outline, title: 'About GEN Z AI', subtitle: 'Version 1.0.0 • Starter'),
    ],
  );
}

class SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const SettingsTile({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 5),
    leading: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(12)),
      child: Icon(icon, color: cyan),
    ),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
    subtitle: Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12)),
  );
}
